#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd #pandas used for importing and cleaning of the data 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

data_frame=pd.read_csv("E:\datasets\heart\heart-disease-uci\heart.csv")
a = pd.get_dummies(data_frame['cp'], prefix = "cp")
b = pd.get_dummies(data_frame['thal'], prefix = "thal")
c = pd.get_dummies(data_frame['slope'], prefix = "slope")
frames = [data_frame, a, b, c]
data_frame = pd.concat(frames, axis = 1)
data_frame = data_frame.drop(columns = ['cp', 'thal', 'slope'])
y = data_frame.target.values
x_data = data_frame.drop(['target'], axis = 1)
#we use 80% data for the testing purpose
x_train, x_test, y_train, y_test = train_test_split(x_data,y,test_size = 0.2,random_state=0)
# Random Forest Classification

rf = RandomForestClassifier(n_estimators = 1000, random_state = 1)
rf.fit(x_train, y_train)

#acc = rf.score(x_test,y_test)*100
#accuracies['Random Forest'] = acc
#print("Random Forest Algorithm Accuracy Score : {:.2f}%".format(acc))

# Saving model to disk
pickle.dump(rf, open('model.pkl','wb'))
# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))

